import React from "react";
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBInput,
  MDBCheckbox,
} from "mdb-react-ui-kit";

const Form = () => {
  return (
    <div>
      <MDBContainer
        fluid
        className="d-flex align-items-center justify-content-center bg-image"
        style={{
          backgroundImage:
            "url(https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp)",
          backgroundSize: "100% auto",
          height: "100%",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="mask gradient-custom-3"></div>
        <MDBCard className="m-5" style={{ maxWidth: "1000px" }}>
          <MDBCardBody className="px-5">
            <h2
              className="text-uppercase text-center mb-5"
              style={{ fontSize: "20px" }}
            >
              User details
            </h2>
            <MDBInput
              wrapperClass="mb-4"
              label="First Name"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Middle Name"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Last Name"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Father Name"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Email"
              size="lg"
              id="form2"
              type="email"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="FDate Of Birth"
              size="lg"
              id="form1"
              type="date"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Phone"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="PAN Number"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Address"
              size="lg"
              id="form1"
              type="text"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Password"
              size="lg"
              id="form3"
              type="password"
            />
            {/* <MDBInput
            wrapperClass="mb-4"
            label="Repeat your password"
            size="lg"
            id="form4"
            type="password"
          /> */}
            <div className="d-flex flex-row justify-content-center mb-4">
              <MDBCheckbox
                name="flexCheck"
                id="flexCheckDefault"
                label="I agree all statements in Terms of service"
              />
            </div>
            <MDBBtn className="mb-4 w-100 gradient-custom-4" size="lg">
              ADD
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>
      </MDBContainer>
    </div>
  );
};

export default Form;
